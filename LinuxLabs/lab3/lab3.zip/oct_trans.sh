#Automating Deposit and debit transactions
#Display the final balance for the month of October

#Deposit and debit transactions 
./deposit.sh balance 1200
./debit.sh balance 390
./debit.sh balance 29
./debit.sh balance 8
./deposit.sh balance 120
./debit.sh balance 50
./debit.sh balance 40
./debit.sh balance 20
./debit.sh balance 9
./deposit.sh balance 1200
./debit.sh balance 200
./debit.sh balance 9
./debit.sh balance 50
./deposit.sh balance 1200
./debit.sh balance 129
./debit.sh balance 80
./debit.sh balance 9
./debit.sh balance 20

#display account balance
./show_balance.sh balance





