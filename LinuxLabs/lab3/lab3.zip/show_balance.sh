#Show Balance of Deposit Account


#This file is to check the balance of what the value is stored.
# add/subtract (deposit / debit)
#the balance currently would be calculated and then the return value updated and 
#save new updated the balance back to the show_balance file
#============================================================================#

read balance < $1



echo "===================="
echo " "
echo "The October balance in your account is"  $balance. 
